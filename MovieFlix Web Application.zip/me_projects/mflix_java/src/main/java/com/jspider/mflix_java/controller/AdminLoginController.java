package com.jspider.mflix_java.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jspider.mflix_java.dao.AdminDao;
import com.jspider.mflix_java.dao.UserDao;
import com.jspider.mflix_java.dto.Admin;
import com.jspider.mflix_java.dto.User;


@WebServlet(value="/adminLogin")
public class AdminLoginController extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException
	{
		AdminDao adminDao=new AdminDao();
		
		String email =req.getParameter("adminEmail");
		String password=req.getParameter("adminPassword");
		
		Admin admin=adminDao.fetchAdminByEmailForLoginDao(email);
		
		if(admin!=null)
		{
			if(admin.getAdminPassword().equals(password))
			{
				req.getRequestDispatcher("admin-home.jsp").forward(req,resp);
			}
			else {
				req.setAttribute("adminMsg","password is invalid");
				req.getRequestDispatcher("admin-login.jsp").forward(req,resp);
			}
		}
		else {
			req.setAttribute("adminMsg","email  is invalid");
			req.getRequestDispatcher("admin-login.jsp").forward(req,resp);
		}
		
	}
	
}
