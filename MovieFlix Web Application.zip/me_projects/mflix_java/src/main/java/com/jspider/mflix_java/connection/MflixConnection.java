package com.jspider.mflix_java.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MflixConnection {
	
	
	/*
	 * connection method
	 */
	
	public static  Connection getMFlixConnection()
	{	
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			
			String url="jdbc:mysql://localhost:3306/mflix";
			String user="root";
			String pass="root";
			
			 return DriverManager.getConnection(url,user,pass);
			
		} catch(SQLException|ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
}
