package com.jspider.mflix_java.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jspider.mflix_java.connection.MflixConnection;
import com.jspider.mflix_java.dto.Admin;

public class AdminDao {

	private Connection connection=MflixConnection.getMFlixConnection();
	
	/*
	 * database queries
	 */
	
	private final String SELECT_QUERY_FOR_Login="SELECT email,password FROM admin where email=?";
	
	/**
	 * created fetchAdminByEmailForLogin() method
	 * @return Admin
	 */
	
	public Admin fetchAdminByEmailForLoginDao(String adminEmail)
	{
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_QUERY_FOR_Login);
			
			preparedStatement.setString(1,adminEmail);
			
			ResultSet resultSet=preparedStatement.executeQuery();
			
			resultSet.next();
			
			String email=resultSet.getString("email");
			String password=resultSet.getString("password");
			
			return new Admin(email, password);
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		
	}
	
}
